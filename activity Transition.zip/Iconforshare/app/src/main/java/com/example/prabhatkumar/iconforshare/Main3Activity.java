package com.example.prabhatkumar.iconforshare;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Main3Activity extends MainActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
    }
}
